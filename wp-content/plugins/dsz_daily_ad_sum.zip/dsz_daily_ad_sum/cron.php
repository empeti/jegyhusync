<?php
    require_once(__DIR__.'/../../../wp-load.php');
    require_once(__DIR__.'/inc/das.class.php');

    DAS::send_daily_ad_sum_mail();